package com.igl.crowdword.fxns;

/**
 * Created by Kunal on 7/12/2015.
 */
public class saveFxns {
    public void savetoDB(User u,UserDetails ud){

    }
}
