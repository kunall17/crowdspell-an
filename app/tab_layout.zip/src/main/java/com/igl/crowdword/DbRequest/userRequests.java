package com.igl.crowdword.DbRequest;

import com.igl.crowdword.fxns.User;

/**
 * Created by Kunal on 7/20/2015.
 */
public class userRequests {

    public static void saveToDB(User user){ //Returns token

    }

    public static String checkIfUserTokenAvailable()
    {

        return null;
    }

}
