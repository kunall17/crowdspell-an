package com.igl.crowdword;

import android.app.Activity;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.RequiresPermission;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.support.v7.internal.widget.AdapterViewCompat;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.igl.crowdword.HTTPRequest.GameManager;
import com.igl.crowdword.HTTPRequest.UserManager;
import com.igl.crowdword.core.UserFunctions;
import com.igl.crowdword.fxns.Tag;
import com.igl.crowdword.fxns.Word;
import com.igl.crowdword.fxns.WordSet;
import com.igl.crowdword.fxns.analysis.UserPoints;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class DashboardActivity extends ActionBarActivity {

    SwipeRefreshLayout srl;

    WordSet wordset = null;
    List<WordSet> Wordset = null;
    List<WordSet> wordset_list = null;
    List<WordSet> backup_wordset_list = null;

    private Toolbar toolbar;
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    ImageButton FAB;

    String[] tags_array;
    Context context;

    ArrayAdapter<String> spn_adapter;
    ArrayAdapter<String> mainListViewAdapter;

    AutoCompleteTextView actv;

    ListView listview_games;
    Map tags_map = new HashMap();
    List<String> allTags;
    FloatingActionButton fab;

    String getJson() {
        InputStream is = getResources().openRawResource(R.raw.getwords);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return writer.toString();

    }

    public List<String> extractTags() {

        List<String> tags_f = new ArrayList<String>();
        for (int i = 0; i < wordset_list.size(); i++) {
            for (Tag tag : wordset_list.get(i).getTags()) {
                if (tags_f.contains(tag.getName().toString()) == false) {
                    tags_f.add(tag.getName().toString());

                    if (tags_map.containsKey(tag.getName())) {
                        tags_map.put(tag.getName().toString(), tags_map.get(tag.getName()).toString() + "," + i);

                    } else {
                        tags_map.put(tag.getName().toString(), i);

                    }
                }
            }
        }
        return tags_f;
    }


    public void filterWithTags() {

        if (spn_adapter.getCount() >= 1) {
            System.out.println("We Are Here:");
            List<WordSet> wordsets_new = new ArrayList<WordSet>();

            for (int i = 0; i < spn_adapter.getCount(); i++) {
                String tag = spn_adapter.getItem(i).toString();
                if (tags_map.containsKey(tag) == true) {
                    String key = tags_map.get(tag).toString();
                    String asd[] = key.split(",");
                    for (String s : asd) {
                        if (wordsets_new.contains(wordset_list.get(Integer.parseInt(s))) == false)
                            wordsets_new.add(wordset_list.get(Integer.parseInt(s)));
                    }
                }
            }
            if (wordsets_new.size() == 0) {
                Toast.makeText(this, "Sorry Nothing Found.!", Toast.LENGTH_LONG).show();
            } else {

                mainListViewAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, getNameArray(wordsets_new));
                listview_games.setAdapter(mainListViewAdapter);
            }

        }

        if (srl.isRefreshing()) srl.setRefreshing(false);
    }

    List<WordSet> wordsets_new;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        context = this;

        srl = (SwipeRefreshLayout) findViewById(R.id.refreshSwipe_list);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                filterWithTags();
                Toast.makeText(context, "ASD", Toast.LENGTH_LONG).show();
            }
        });


        //String json = getResources().getString(R.string.testing_json).toString();


//String[] drawer_together = ArrayUtils.addAll(drawer_navigation,drawer_sets,drawer_sets);

// This patch of code can be made better
//        for (int i = 0; i < drawer_navigation.length; i++) {
//            drawer_together[i] = drawer_navigation[i];
//        }
//
//        int x = drawer_together.length;
//        for(int i=0;i<drawer_sets.length; i++){
//            drawer_together[x+i]=drawer_sets[i];
//        }
//
//        x= drawer_together.length;
//        for(int i=0;i<drawer_more.length; i++){
//            drawer_together[x+i]=drawer_more[i];
//        }


//Till heree
        actv = (AutoCompleteTextView) findViewById(R.id.tags_actv);


        listview_games = (ListView) findViewById(R.id.game_list);

        String[] nameArray = null;
//        try {
////       List<WordSet> Wordsetx = asd.readValue(s,new TypeReference<List<WordSet>>(){});
//
//  //          wordset = Wordsetx.get(1);
//    //        System.out.println("NAMe: 0"+wordset.getName());
//
//             // nameArray = new String[Wordsetx.size()];
//
//      //  } catch (IOException e) {
//        //    e.printStackTrace();
//        }
//
        String json1 = "";
        if (UserFunctions.checkForServer(this) == true) {
            GameManager.getAllSetsAsync asd = new GameManager.getAllSetsAsync();
            json1 = String.valueOf(asd.execute(this));
        } else {
            json1 = getJson();
        }
        JsonElement json = new JsonParser().parse(json1);
        JsonArray array = json.getAsJsonArray();
        Iterator iterator = array.iterator();
        wordset_list = new ArrayList<WordSet>();
        int i = 0;
        nameArray = new String[array.size()];

        while (iterator.hasNext()) {
            JsonElement json2 = (JsonElement) iterator.next();
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
            WordSet wordset = gson.fromJson(json2, WordSet.class);
            nameArray[i] = wordset.getName();
            i++;
            wordset_list.add(wordset);
        }
        wordsets_new = wordset_list;

        mainListViewAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nameArray);
        //ArrayAdapter<String> adap = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,game_title);
        listview_games.setAdapter(mainListViewAdapter);
        listview_games.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Implement code for navigation to play game
                startGame(position);
            }
        });


//Added Newwly

        allTags = extractTags();
        final ArrayAdapter<String> adapter_actv = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, allTags);

        //Getting the instance of AutoCompleteTextView
        actv.setThreshold(3);//will start working from first character
        actv.setAdapter(adapter_actv);//setting the adapter data into the AutoCompleteTextView


        tags_array = new String[100];
        tags_array[0] = "";


        final ArrayList<String> spn_array = new ArrayList<String>();
        spn_adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, spn_array){

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = null;
                if (position == 0) {
                    TextView tv = new TextView(getContext());
                    tv.setVisibility(View.GONE);
                    v = tv;
                } else {
                    v = super.getDropDownView(position, null, parent);
                }
                return v;
            }
        };
        Spinner spinner = (Spinner) findViewById(R.id.tags_spnr);

        spn_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spn_adapter);


        actv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spn_adapter.add(adapter_actv.getItem(position));
                Toast.makeText(getBaseContext(), "Tag Added", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }


        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                Toast.makeText(getBaseContext(), "SUPER", Toast.LENGTH_LONG).show();
//                spn_adapter.remove( spn_adapter.getItem(position) );
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }

        });

        spn_adapter.add("Add Tags Here");
        toolbar = (Toolbar) findViewById(R.id.toolbar_dashboard);
        toolbar.setTitle("DashBoard");

        setSupportActionBar(toolbar);
        //Initializing NavigationView
        navigationView = (NavigationView) findViewById(R.id.navigation_view);

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {


                //Checking if the item is in checked state or not, if not make it in checked state
                if (menuItem.isChecked()) menuItem.setChecked(false);
                else menuItem.setChecked(true);

                //Closing drawer on item click
                drawerLayout.closeDrawers();

                //Check to see which item was being clicked and perform appropriate action
                switch (menuItem.getItemId()) {


                    //Replacing the main content with ContentFragment Which is our Inbox View;
                    case R.id.drawer_profile:

                        Intent in = new Intent(DashboardActivity.this, ProfileActivity.class);
                        startActivity(in);
                        return true;

                    // For rest of the options we just show a toast on click

                    case R.id.drawer_create:
                        Intent in1 = new Intent(DashboardActivity.this, CreateSetActivity.class);
                        startActivity(in1);
                        return true;
                    case R.id.drawer_exit:
                        AlertDialog.Builder builder = new AlertDialog.Builder(DashboardActivity.this);
                        builder.setTitle("Exit?");
                        builder.setMessage("Are you Sure you want to Exit?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                System.exit(0);
                            }
                        });
                        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        return true;
                    case R.id.drawer_popular:
                        spn_adapter.add("mostpopular");
                        return true;
                    case R.id.drawer_rated:
                        spn_adapter.add("mostrated");
                        return true;
                    case R.id.drawer_suprise:
                        Random rnd = new Random();
                        final int x = rnd.nextInt(wordset_list.size());
                        WordSet wordset = wordset_list.get(x);

                        new AlertDialog.Builder(DashboardActivity.this)
                                .setTitle("Suprise Me")
                                .setMessage("Do you want to play " + wordset.getName() + "?")
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        startGame(x);
                                    }
                                })
                                .setNegativeButton(android.R.string.no, null).show();
                        return true;
                    case R.id.drawer_leaderboard:
                        List<UserPoints> userPoints;

                        try {
                            userPoints = GameManager.getAllTopScorers();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                }
                return true;
            }
        });

        // Initializing Drawer Layout and ActionBarToggle
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                // Code here will be triggered once the drawer closes as we dont want anything to happen so we leave this blank
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                // Code here will be triggered once the drawer open as we dont want anything to happen so we leave this blank

                super.onDrawerOpened(drawerView);
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessay or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1 = new Intent(DashboardActivity.this, CreateSetActivity.class);
                startActivity(in1);

            }
        });


    }

    public void startGame(int position) {
        Intent in1 = new Intent(DashboardActivity.this, GameNewActivity.class);

        Gson gson = new Gson();
        String json_new = gson.toJson(wordsets_new.get(position)).toString();

        in1.putExtra("json_new", json_new);
        in1.putExtra("wordTitle", "TITLE");

        WordSet asd = new WordSet();
        String json_wordset = null;
        ObjectMapper mapper = new ObjectMapper();

        try {
            json_wordset = mapper.writeValueAsString(asd);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        in1.putExtra("json_wordset", json_wordset);
        //in1.putExtra ("wordName", game_word[position].toUpperCase());
        startActivity(in1);
    }

    public void addTag_btn(View v) {
        spn_adapter.add(actv.getText().toString());
        Toast.makeText(this, "Tag Added", Toast.LENGTH_LONG).show();
        actv.setText("");
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dashboard, menu);
        SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        //SearchView searchView =
        //       (SearchView) menu.findItem(R.id.search).getActionView();
        MenuItem mSearchMenuItem = menu.findItem(R.id.search);
        SearchView searchView =
                (SearchView)MenuItemCompat.getActionView(mSearchMenuItem);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(
                new ComponentName(getApplicationContext(),
                        DashboardActivity.class)));



        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));


        searchView.setIconifiedByDefault(false);

        SearchView.OnQueryTextListener textChangeListener = new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextChange(String newText)
            {
                // this is your adapter that will be filtered
//                myAdapter.getFilter().filter(newText);
                System.out.println("on text chnge text: "+newText);
                return true;
            }
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                // this is your adapter that will be filtered
//                myAdapter.getFilter().filter(query);
                System.out.println("on query submit: "+query);
                return true;
            }
        };
        searchView.setOnQueryTextListener(textChangeListener);

        return super.onCreateOptionsMenu(menu);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        } else if (id == R.id.menu_dashboard_search) {
            UserManager usm = new UserManager();
            String search = ""; //TODO search get as astring;
            List<WordSet> wordsetss;
            GameManager.searchAsync asd = new GameManager.searchAsync();

            //TODO   wordsetss = asd.execute(search);

        }

        return super.onOptionsItemSelected(item);
    }

    public List<String> getNameArray(List<WordSet> wordsets_list) {
        List<String> nameArray = new ArrayList<String>();

        for (WordSet wordset : wordsets_list) {
            nameArray.add(wordset.getName());
        }
        return nameArray;
    }

    /**
     * A placeholder fragment containing a simple view.
     */




    class pagerAdapter extends FragmentStatePagerAdapter{

        public pagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return null;
        }

        @Override
        public int getCount() {
            return 0;
        }
    }
}
