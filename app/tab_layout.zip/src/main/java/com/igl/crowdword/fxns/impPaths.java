package com.igl.crowdword.fxns;

/**
 * Created by Kunal on 7/16/2015.
 */
public class impPaths {

    public static final String USERS = "users";
    public static final String SETS = "sets";
    public static final String SCORES = "scores";
    public static final String PARAM_ID = "id";
    public static final String SORT_TOP = "top";
    public static final String SORT_NEW = "new";
    public static final String LOGIN = "login";

}
