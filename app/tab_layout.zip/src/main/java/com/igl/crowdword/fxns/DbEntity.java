package com.igl.crowdword.fxns;

/**
 * Created by Kunal on 7/16/2015.
 */
public class DbEntity {
}
