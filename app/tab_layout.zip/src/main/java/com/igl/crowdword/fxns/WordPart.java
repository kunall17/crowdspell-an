package com.igl.crowdword.fxns;

/**
 * Created by MAHE on 9/16/2015.
 */
public class WordPart {
    private char r1;
    private char r2;
    private char p1;

    public char getR1() {
        return r1;
    }

    public void setR1(char r1) {
        this.r1 = r1;
    }

    public char getR2() {
        return r2;
    }

    public void setR2(char r2) {
        this.r2 = r2;
    }

    public char getP1() {
        return p1;
    }

    public void setP1(char p1) {
        this.p1 = p1;
    }
}
